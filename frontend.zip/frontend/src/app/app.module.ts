import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { LoginComponent } from './pages/login/login.component';
import {RegisterComponent} from './pages/register/register.component';
import {AuthGuard} from './pages/auth/auth.guard';
import {AuthService} from './pages/auth/auth.service';
import { AngularFireModule } from 'angularfire2';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabaseModule } from 'angularfire2/database';

import { AppComponent } from './app.component';
import { NavBarComponent } from './shared/nav-bar/nav-bar.component';
import { SideNavComponent } from './shared/side-nav/side-nav.component';
import { HomeComponent } from './pages/home/home.component';
import { AppRoutingModule } from './app-routing.module';
import { FooterBarComponent } from './shared/footer-bar/footer-bar.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Model1Component} from './pages/model1/model1.component';
import {DenseNet121Component} from './pages/models/dense-net121/dense-net121.component';
import { InceptionV3Component } from './pages/models/inception-v3/inception-v3.component';
import { MobileNetComponent } from './pages/models/mobile-net/mobile-net.component';
import { NasnetComponent } from './pages/models/nasnet/nasnet.component';
import { ResNet50Component } from './pages/models/res-net50/res-net50.component';
import { VGG16Component } from './pages/models/vgg16/vgg16.component';
import { XceptionComponent } from './pages/models/xception/xception.component';

// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC9arBsuCZKSugc66UM1w2VGq-Kk_GWfaY",
  authDomain: "myapp-6b5f2.firebaseapp.com",
  databaseURL: "https://myapp-6b5f2.firebaseio.com",
  projectId: "myapp-6b5f2",
  storageBucket: "myapp-6b5f2.appspot.com",
  messagingSenderId: "700936391623"
};

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    SideNavComponent,
    HomeComponent,
    FooterBarComponent,
    Model1Component,
    DenseNet121Component,
    InceptionV3Component,
    MobileNetComponent,
    NasnetComponent,
    ResNet50Component,
    VGG16Component,
    XceptionComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(firebaseConfig)
  ],
  providers: [
    AngularFireAuth,
    AuthGuard,
    AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
